// main.m<2> (this is -*- ObjC -*-)
// 
// \author: Bj�rn Giesler <giesler@ira.uka.de>
// 
// 
// 
// $Author: rmottola $
// $Locker:  $
// $Revision: 1.1 $
// $Date: 2007/03/29 22:37:41 $

#include <AppKit/AppKit.h>

int main(int argc, const char** argv)
{
  return NSApplicationMain(argc, argv);
}
